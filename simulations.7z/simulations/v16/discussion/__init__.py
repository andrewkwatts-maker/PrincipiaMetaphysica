"""
Discussion section for Principia Metaphysica v16.0
"""

from .discussion_v16_0 import DiscussionV16

__all__ = ['DiscussionV16']
