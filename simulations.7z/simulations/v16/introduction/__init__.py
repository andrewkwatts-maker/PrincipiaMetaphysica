"""
Introduction simulations for Principia Metaphysica v16.0
"""

from .introduction_v16_0 import IntroductionV16

__all__ = ['IntroductionV16']
