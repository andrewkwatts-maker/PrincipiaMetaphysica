"""
Test suite for Principia Metaphysica simulation framework.

Copyright (c) 2025-2026 Andrew Keith Watts. All rights reserved.
"""
