#!/usr/bin/env python3
"""
Appendix I: Gravitational Wave Dispersion v16.0
===============================================

The two-time framework predicts a small frequency-dependent dispersion for gravitational
waves propagating through compactified dimensions. The dispersion coefficient η emerges
from quantum fluctuations in the orthogonal time coordinate τ, modulated by G₂ torsion effects.

Derivation chain:
1. Two-time metric: ds² = -dt_therm² - dτ² + dx_i² before gauge fixing
2. Flux quantization: N_flux = χ_eff/6 = 144/6 = 24
3. Torsion coupling: T_ω = -b₃/N_flux = -24/24 = -1.000 modulates τ sector
4. Quantum fluctuations: ⟨δτ²⟩ ~ e^|T_ω|/b₃
5. Dispersion coefficient: η = e^|T_ω|/b₃ = e^1.0/24 ≈ 0.113

With Spin(7) correction: T_ω = -0.875, giving η ≈ 0.100

Dispersion relation: ω² = k²c² + η·k⁴/M_GW²

Testable by LISA (2037+) at frequencies f ~ 10⁻³ - 10⁻¹ Hz.

References:
- Acharya (2001) "M theory, Joyce orbifolds and super Yang-Mills"
- Halverson & Taylor (2019) "ℙ¹-bundle bases and the prevalence of non-higgsable structure"
- Bars (2011) "Survey of two-time physics"

Copyright (c) 2025-2026 Andrew Keith Watts. All rights reserved.
"""

import numpy as np
from typing import Dict, Any, List, Optional
import sys
import os

# Add parent directories to path for imports
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.insert(0, project_root)

from simulations.base import (
    SimulationBase,
    SimulationMetadata,
    Formula,
    Parameter,
    SectionContent,
    ContentBlock,
)


class AppendixIGWDispersion(SimulationBase):
    """
    Appendix I: Gravitational Wave Dispersion

    Derives GW dispersion from two-time framework and torsion effects.
    """

    @property
    def metadata(self) -> SimulationMetadata:
        """Return simulation metadata."""
        return SimulationMetadata(
            id="appendix_i_v16_0",
            version="16.0",
            domain="appendices",
            title="Appendix I: Gravitational Wave Dispersion",
            description=(
                "The two-time framework predicts frequency-dependent dispersion for gravitational waves. "
                "Dispersion coefficient η emerges from quantum fluctuations in orthogonal time τ, "
                "modulated by G₂ torsion effects."
            ),
            section_id="8",
            subsection_id="I"
        )

    @property
    def required_inputs(self) -> List[str]:
        """Return list of required input parameter paths."""
        return [
            "topology.b3",
            "gauge.M_GUT",
        ]

    @property
    def output_params(self) -> List[str]:
        """Return list of output parameter paths."""
        return [
            "gw_dispersion.eta",
            "gw_dispersion.M_GW",
        ]

    @property
    def output_formulas(self) -> List[str]:
        """Return list of formula IDs this simulation provides."""
        return [
            "gw-dispersion-relation",
            "gw-dispersion-coefficient",
        ]

    def run(self, registry: 'PMRegistry') -> Dict[str, Any]:
        """
        Execute GW dispersion calculation.

        Args:
            registry: PMRegistry instance with input parameters

        Returns:
            Dictionary with dispersion predictions
        """
        # Get input parameters
        b3 = registry.get_param("topology.b3")  # Third Betti number = 24
        T_omega = -0.875  # Effective torsion (hardcoded)
        M_GUT = registry.get_param("gauge.M_GUT")  # GUT scale in GeV

        # === GW Dispersion Scale ===
        # The dispersion scale is set by G₂ compactification
        # M_GW ~ M_GUT (scale of compact dimensions)
        M_GW = M_GUT  # GeV

        # === Dispersion Coefficient ===
        # η = e^|T_ω|/b₃
        # This emerges from quantum fluctuations in orthogonal time τ
        eta = np.exp(abs(T_omega)) / b3

        # === Alternative Derivations ===
        # Topological (T_ω = -1.000):
        T_omega_topo = -1.000
        eta_topological = np.exp(abs(T_omega_topo)) / b3  # = e^1.0/24 ≈ 0.113

        # Phenomenological (T_ω = -0.882):
        T_omega_pheno = -0.882
        eta_pheno = np.exp(abs(T_omega_pheno)) / b3  # ≈ 0.101

        # === Dispersion Frequency Scale ===
        # The dispersion becomes significant at frequency f_disp ~ η^(1/2) M_GW
        # For LISA sensitivity, we need f_disp ~ 10⁻³ - 10⁻¹ Hz
        c = 299792458  # m/s (speed of light)
        hbar = 6.582119569e-25  # GeV·s

        # Convert M_GW to Hz: f = M_GW c² / (2π ℏ)
        f_GW_Hz = (M_GW * 1e9) * c**2 / (2 * np.pi * hbar * 1e9)  # Hz

        # Dispersion frequency scale
        f_disp_Hz = np.sqrt(eta) * f_GW_Hz

        # === Time Delay for GW Signals ===
        # For a source at distance D, the time delay between high and low frequency
        # components is approximately:
        # Δt ≈ η D (Δf/f)² / (2 M_GW²)
        # For typical LISA sources (D ~ 1 Gpc, Δf/f ~ 0.1):
        # Δt ~ microseconds to milliseconds (potentially detectable)

        return {
            "gw_dispersion.eta": eta,
            "gw_dispersion.M_GW": M_GW,
            "gw_dispersion.eta_topological": eta_topological,
            "gw_dispersion.eta_pheno": eta_pheno,
            "gw_dispersion.f_GW_Hz": f_GW_Hz,
            "gw_dispersion.f_disp_Hz": f_disp_Hz,
            "gw_dispersion.T_omega_used": T_omega,
        }

    def get_section_content(self) -> Optional[SectionContent]:
        """
        Return section content for Appendix I - GW Dispersion.

        Returns:
            SectionContent with GW dispersion derivation
        """
        return SectionContent(
            section_id="8",
            subsection_id="I",
            title="Appendix I: Gravitational Wave Dispersion",
            abstract=(
                "The two-time framework predicts a small frequency-dependent dispersion for "
                "gravitational waves propagating through compactified dimensions. The dispersion "
                "coefficient η emerges from quantum fluctuations in the orthogonal time coordinate τ, "
                "modulated by G₂ torsion effects."
            ),
            content_blocks=[
                ContentBlock(
                    type="subsection",
                    content="I.1 Orthogonal Time and GW Propagation"
                ),
                ContentBlock(
                    type="paragraph",
                    content=(
                        "The hidden time coordinate τ ≡ t_ortho in the (24,2) signature affects GW "
                        "propagation even though it is gauge-fixed at the classical level. Quantum "
                        "fluctuations around the gauge-fixed trajectory ⟨X·P⟩ = 0 induce an effective "
                        "dispersion relation:"
                    )
                ),
                ContentBlock(
                    type="formula",
                    content=r"\omega^2 = k^2 c^2 + \eta \cdot k^4 / M_{\text{GW}}^2",
                    formula_id="gw-dispersion-relation",
                    label="(I.1)"
                ),
                ContentBlock(
                    type="paragraph",
                    content=(
                        "where M_GW ~ M_GUT is the scale set by G₂ compactification. The dispersion "
                        "coefficient η is determined by the torsion class T_ω which modulates the "
                        "coupling between physical time t_therm and orthogonal time τ:"
                    )
                ),
                ContentBlock(
                    type="subsection",
                    content="I.2 Dispersion Formula"
                ),
                ContentBlock(
                    type="paragraph",
                    content=(
                        "This predicts high-frequency GWs arrive slightly before low-frequency components. "
                        "Testable by LISA (2037+). The formula uses T_ω = -1.000 from N_flux = χ_eff/6."
                    )
                ),
                ContentBlock(
                    type="formula",
                    content=r"\eta = \frac{e^{|T_\omega|}}{b_3} = \frac{e^{1.0}}{24} \approx 0.113",
                    formula_id="gw-dispersion-coefficient",
                    label="(I.2)"
                ),
                ContentBlock(
                    type="paragraph",
                    content=(
                        "With Spin(7) spinor correction (T_ω = -0.875), this becomes η ≈ 0.100."
                    )
                ),
                ContentBlock(
                    type="subsection",
                    content="I.3 Simulation Code"
                ),
                ContentBlock(
                    type="code",
                    content="""# gw_dispersion_v12_8.py
FLUX_DIVISOR = 6  # Standard G2 flux quantization
N_FLUX = 144 / FLUX_DIVISOR  # = 24
T_OMEGA_GEOMETRIC = -24 / N_FLUX  # = -1.000
B3 = 24

def gw_dispersion(T_omega: float = T_OMEGA_GEOMETRIC, b3: int = B3) -> dict:
    \"\"\"Predict GW dispersion from torsion effects.\"\"\"
    eta = np.exp(np.abs(T_omega)) / b3  # = exp(1.0)/24 = 0.113
    return {
        'eta': eta,
        'formula': 'eta = exp(|T_omega|)/b3',
        'future_test': 'LISA 2037+ (space-based GW detector)'
    }

# Result: eta = 0.113""",
                    language="python",
                    label="Python code for GW dispersion calculation"
                ),
                ContentBlock(
                    type="subsection",
                    content="I.4 Alternative Derivation: Phenomenological Normalization"
                ),
                ContentBlock(
                    type="paragraph",
                    content=(
                        "An alternative approach uses a phenomenologically-fitted normalization constant "
                        "C = 27.2 instead of the standard flux quantization N_flux = χ_eff/6:"
                    )
                ),
                ContentBlock(
                    type="formula",
                    content=r"T_{\omega}^{\text{(alt)}} = -\frac{b_3}{C} = -\frac{24}{27.2} = -0.882",
                    label="(I.3)"
                ),
                ContentBlock(
                    type="paragraph",
                    content=(
                        "This yields η^(alt) = e^0.882/24 ≈ 0.101, which agrees with the "
                        "phenomenological torsion value T_ω = -0.884 to within 0.2%."
                    )
                ),
                ContentBlock(
                    type="subsection",
                    content="I.5 Comparison Table"
                ),
                ContentBlock(
                    type="paragraph",
                    content=(
                        "Comparison of Topological and Spinor-Corrected Derivations:\n\n"
                        "1. Topological base: T_ω = -b₃/N_flux = -24/24 = -1.000, η = 0.113\n"
                        "2. Spinor correction: T_ω = -1.0 × (7/8) = -0.875, η = 0.100\n\n"
                        "The geometric derivation is complete: G₄ flux stabilizes 7 of 8 Spin(7) "
                        "spinor components in 7D G₂ manifolds, giving T_ω = -0.875 with no tuning "
                        "required. This derives from standard G₂ flux quantization (Acharya 2001, "
                        "Halverson-Taylor 2019)."
                    )
                ),
            ],
            formula_refs=[
                "gw-dispersion-relation",
                "gw-dispersion-coefficient",
            ],
            param_refs=[
                "topology.chi_eff",
                "topology.b3",
                "topology.N_flux",
                "topology.T_omega",
                "gauge.M_GUT",
                "gw_dispersion.eta",
                "gw_dispersion.M_GW",
            ]
        )

    def get_formulas(self) -> List[Formula]:
        """
        Return list of formulas for GW dispersion.

        Returns:
            List of Formula instances
        """
        return [
            Formula(
                id="gw-dispersion-relation",
                label="(I.1)",
                latex=r"\omega^2 = k^2 c^2 + \eta \cdot k^4 / M_{\text{GW}}^2",
                plain_text="ω² = k²c² + η·k⁴/M_GW²",
                category="PREDICTION",
                description=(
                    "Gravitational wave dispersion relation with frequency-dependent correction. "
                    "High-frequency GWs arrive slightly before low-frequency components."
                ),
                input_params=["gw_dispersion.eta", "gw_dispersion.M_GW"],
                output_params=[],
            ),
            Formula(
                id="gw-dispersion-coefficient",
                label="(I.2)",
                latex=r"\eta = \frac{e^{|T_\omega|}}{b_3} = \frac{e^{1.0}}{24} \approx 0.113",
                plain_text="η = e^|T_ω|/b₃ = e^1.0/24 ≈ 0.113",
                category="DERIVED",
                description=(
                    "Dispersion coefficient from torsion class and third Betti number. "
                    "Testable by LISA (2037+)."
                ),
                input_params=["topology.T_omega", "topology.b3"],
                output_params=["gw_dispersion.eta"],
                derivation={
                    "parentFormulas": ["effective-torsion"],
                    "method": "Quantum fluctuations in orthogonal time",
                    "steps": [
                        "Two-time metric: ds² = -dt² - dτ² + dx² before gauge fixing",
                        "Quantum fluctuations: ⟨δτ²⟩ ~ e^|T_ω|/b₃",
                        "Torsion class T_ω = -b₃/N_flux modulates τ sector",
                        "Dispersion coefficient: η = e^|T_ω|/b₃",
                        "With T_ω = -0.875: η ≈ 0.100",
                    ]
                },
            ),
        ]

    def get_output_param_definitions(self) -> List[Parameter]:
        """
        Return parameter definitions for GW dispersion outputs.

        Returns:
            List of Parameter instances
        """
        return [
            Parameter(
                path="gw_dispersion.eta",
                name="GW Dispersion Coefficient",
                units="dimensionless",
                status="PREDICTED",
                description="Coefficient for frequency-dependent GW dispersion: η ≈ 0.100",
            ),
            Parameter(
                path="gw_dispersion.M_GW",
                name="GW Dispersion Scale",
                units="GeV",
                status="DERIVED",
                description="Mass scale for GW dispersion (M_GW ~ M_GUT)",
            ),
        ]


def main():
    """Run the appendix standalone for testing."""
    import io
    import sys

    # Ensure UTF-8 output encoding
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

    from simulations.base import PMRegistry
    from simulations.base.established import EstablishedPhysics

    # Create registry and load established physics
    registry = PMRegistry()
    EstablishedPhysics.load_into_registry(registry)

    # Add topology parameters if needed
    if not registry.has_param("topology.b3"):
        registry.set_param("topology.b3", 24)
    if not registry.has_param("topology.T_omega"):
        registry.set_param("topology.T_omega", -0.875)

    # Create and run appendix
    appendix = AppendixIGWDispersion()

    print("=" * 70)
    print(f" {appendix.metadata.title}")
    print("=" * 70)
    print(f"Appendix ID: {appendix.metadata.id}")
    print(f"Version: {appendix.metadata.version}")
    print(f"Section: {appendix.metadata.section_id}.{appendix.metadata.subsection_id}")
    print()

    # Execute
    results = appendix.execute(registry, verbose=True)

    # Print results
    print("\n" + "=" * 70)
    print(" GW DISPERSION PREDICTIONS")
    print("=" * 70)
    print(f"η (dispersion coefficient): {results.get('gw_dispersion.eta', 0):.4f}")
    print(f"η (topological): {results.get('gw_dispersion.eta_topological', 0):.4f}")
    print(f"η (phenomenological): {results.get('gw_dispersion.eta_pheno', 0):.4f}")
    print(f"M_GW: {results.get('gw_dispersion.M_GW', 0):.2e} GeV")
    print(f"f_disp: {results.get('gw_dispersion.f_disp_Hz', 0):.2e} Hz")
    print()
    print("Future test: LISA (2037+)")
    print()


if __name__ == "__main__":
    main()
