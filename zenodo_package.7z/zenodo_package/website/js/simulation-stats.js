/**
 * Principia Metaphysica - Dynamic Simulation Statistics
 * ======================================================
 *
 * Calculates and serves dynamic statistics from simulation output.
 * Reads from theory_output.json and provides quotes for the paper.
 *
 * EXCLUDES: Biological/speculative simulations (microtubule, consciousness)
 *
 * Usage:
 *   - Include this script after theory-constants-enhanced.js
 *   - Access via PM.stats object
 *   - Dynamic values auto-populate elements with data-pm-stat attributes
 *
 * Copyright (c) 2025 Andrew Keith Watts. All rights reserved.
 */

(function() {
    'use strict';

    // Biological/speculative simulations to exclude from core statistics
    const EXCLUDED_SIMULATIONS = [
        'microtubule',
        'consciousness',
        'orch_or',
        'biological'
    ];

    // Simulation metadata with experimental comparisons
    const SIMULATION_METADATA = {
        'proton_decay': {
            name: 'Proton Lifetime',
            prediction_key: 'tau_p_years',
            experimental_value: 1.6e34,
            experimental_source: 'Super-K 2020',
            unit: 'years',
            is_core: true
        },
        'higgs_mass': {
            name: 'Higgs Mass',
            prediction_key: 'm_h',
            experimental_value: 125.25,
            experimental_uncertainty: 0.17,
            experimental_source: 'ATLAS+CMS 2023',
            unit: 'GeV',
            is_core: true
        },
        'neutrino_masses': {
            name: 'Neutrino Mass Sum',
            prediction_key: 'sum_m_nu',
            experimental_value: 0.06,
            experimental_uncertainty: 0.02,
            experimental_source: 'Cosmological bounds',
            unit: 'eV',
            is_core: true
        },
        'multi_sector_v16': {
            name: 'DM/Baryon Ratio',
            prediction_key: 'mirror_dm_fraction',
            experimental_value: 5.4,
            experimental_uncertainty: 0.5,
            experimental_source: 'Planck 2018',
            unit: '',
            is_core: true,
            is_geometric: true
        },
        'yukawa_overlap_v15': {
            name: 'Yukawa Couplings',
            is_core: true
        },
        'cp_phase': {
            name: 'CP Phase',
            prediction_key: 'delta_cp',
            experimental_value: 232,
            experimental_uncertainty: 28,
            experimental_source: 'NuFIT 2023',
            unit: 'deg',
            is_core: true
        }
    };

    // Stats object to be attached to PM
    const SimulationStats = {
        // Raw data cache
        _data: null,
        _lastUpdate: null,

        // Load data from theory_output.json (or Firebase)
        async loadData() {
            try {
                // Try loading from local JSON first
                const response = await fetch('theory_output.json');
                if (response.ok) {
                    this._data = await response.json();
                    this._lastUpdate = new Date().toISOString();
                    return true;
                }
            } catch (e) {
                console.warn('SimulationStats: Could not load theory_output.json:', e);
            }

            // Fallback to Firebase if available
            if (typeof firebase !== 'undefined' && firebase.database) {
                try {
                    const snapshot = await firebase.database().ref('/simulations').once('value');
                    this._data = { simulations: snapshot.val() };
                    this._lastUpdate = new Date().toISOString();
                    return true;
                } catch (e) {
                    console.warn('SimulationStats: Could not load from Firebase:', e);
                }
            }

            return false;
        },

        // Filter out excluded (biological) simulations
        getCoreSimulations() {
            if (!this._data || !this._data.simulations) return {};

            const core = {};
            for (const [key, value] of Object.entries(this._data.simulations)) {
                const isExcluded = EXCLUDED_SIMULATIONS.some(ex =>
                    key.toLowerCase().includes(ex)
                );
                if (!isExcluded) {
                    core[key] = value;
                }
            }
            return core;
        },

        // Count validations
        getValidationCounts() {
            const sims = this.getCoreSimulations();
            let passed = 0;
            let total = 0;

            for (const [key, sim] of Object.entries(sims)) {
                if (sim && typeof sim === 'object') {
                    total++;
                    if (sim.overall_valid === true || sim.valid === true) {
                        passed++;
                    }
                }
            }

            return {
                passed,
                total,
                percentage: total > 0 ? (passed / total * 100).toFixed(1) : '0'
            };
        },

        // Calculate sigma deviations for predictions with experimental data
        getSigmaStatistics() {
            const sims = this.getCoreSimulations();
            const sigmas = [];
            const details = [];

            for (const [key, meta] of Object.entries(SIMULATION_METADATA)) {
                if (!meta.experimental_value || !sims[key]) continue;

                const sim = sims[key];
                const predKey = meta.prediction_key;
                const predicted = sim[predKey];

                if (predicted === undefined) continue;

                const exp = meta.experimental_value;
                const unc = meta.experimental_uncertainty || (exp * 0.1); // Default 10% if not specified

                const sigma = Math.abs(predicted - exp) / unc;
                sigmas.push(sigma);

                details.push({
                    name: meta.name,
                    predicted,
                    experimental: exp,
                    uncertainty: unc,
                    sigma: sigma.toFixed(2),
                    unit: meta.unit,
                    source: meta.experimental_source,
                    is_geometric: meta.is_geometric || false
                });
            }

            const within1sigma = sigmas.filter(s => s <= 1).length;
            const within2sigma = sigmas.filter(s => s <= 2).length;
            const within3sigma = sigmas.filter(s => s <= 3).length;
            const meanSigma = sigmas.length > 0
                ? (sigmas.reduce((a, b) => a + b, 0) / sigmas.length).toFixed(2)
                : 'N/A';

            return {
                count: sigmas.length,
                within_1sigma: within1sigma,
                within_2sigma: within2sigma,
                within_3sigma: within3sigma,
                mean_sigma: meanSigma,
                details
            };
        },

        // Count geometric vs calibrated parameters
        getParameterCounts() {
            const sims = this.getCoreSimulations();
            let geometric = 0;
            let calibrated = 0;
            let total = 0;

            for (const [key, sim] of Object.entries(sims)) {
                if (!sim || typeof sim !== 'object') continue;

                // Check if simulation has geometric derivation flag
                if (sim.is_geometric === true || sim.width_source === 'G2_wavefunction_overlap') {
                    geometric++;
                } else if (sim.is_calibrated === true) {
                    calibrated++;
                }
                total++;
            }

            return {
                geometric,
                calibrated,
                total,
                geometric_percentage: total > 0 ? (geometric / total * 100).toFixed(1) : '0'
            };
        },

        // Get v16 specific statistics
        getV16Stats() {
            const sims = this.getCoreSimulations();
            const v16 = sims['multi_sector_v16'];

            if (!v16) return null;

            return {
                modulation_width: v16.modulation_width?.toFixed(4) || 'N/A',
                width_source: v16.width_source || 'unknown',
                is_geometric: v16.is_geometric || false,
                dm_ratio: v16.mirror_dm_fraction?.toFixed(2) || 'N/A',
                dm_deviation_pct: v16.dm_deviation_pct?.toFixed(1) || 'N/A',
                planck_target: 5.4
            };
        },

        // Generate dynamic quotes for paper
        getQuotes() {
            const validation = this.getValidationCounts();
            const sigma = this.getSigmaStatistics();
            const params = this.getParameterCounts();
            const v16 = this.getV16Stats();

            return {
                // Validation summary
                validation_summary: `${validation.passed}/${validation.total} core predictions validated`,
                validation_percentage: `${validation.percentage}%`,

                // Sigma statistics
                sigma_summary: `${sigma.within_1sigma}/${sigma.count} predictions within 1σ`,
                mean_sigma: sigma.mean_sigma,
                sigma_detail: sigma.within_1sigma > 0
                    ? `Mean deviation: ${sigma.mean_sigma}σ across ${sigma.count} testable predictions`
                    : 'Sigma statistics unavailable',

                // Parameter counts
                geometric_count: params.geometric,
                calibrated_count: params.calibrated,
                parameter_summary: `${params.geometric} geometric derivations, ${params.calibrated} calibrated`,

                // v16 specific
                v16_width: v16 ? v16.modulation_width : 'N/A',
                v16_dm_ratio: v16 ? v16.dm_ratio : 'N/A',
                v16_dm_deviation: v16 ? `${v16.dm_deviation_pct}%` : 'N/A',
                v16_source: v16 ? v16.width_source : 'N/A',
                v16_summary: v16
                    ? `DM/baryon ratio ${v16.dm_ratio} (${v16.dm_deviation_pct}% from Planck 5.4) derived geometrically`
                    : 'v16 data unavailable',

                // Timestamps
                last_update: this._lastUpdate || 'unknown'
            };
        },

        // Populate elements with data-pm-stat attributes
        populateStats() {
            const quotes = this.getQuotes();
            const elements = document.querySelectorAll('[data-pm-stat]');

            elements.forEach(el => {
                const key = el.getAttribute('data-pm-stat');
                if (quotes[key] !== undefined) {
                    el.textContent = quotes[key];
                    el.classList.add('pm-stat-loaded');
                } else {
                    el.classList.add('pm-stat-missing');
                }
            });
        },

        // Initialize on page load
        async init() {
            const loaded = await this.loadData();
            if (loaded) {
                this.populateStats();
                console.log('SimulationStats initialized:', this.getQuotes());
            } else {
                console.warn('SimulationStats: No data available');
            }
        }
    };

    // Attach to PM object if it exists
    if (typeof PM !== 'undefined') {
        PM.stats = SimulationStats;
    } else {
        window.PM = { stats: SimulationStats };
    }

    // Auto-initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => SimulationStats.init());
    } else {
        SimulationStats.init();
    }

})();
